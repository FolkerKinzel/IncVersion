IncVersion is a very small platform-independent .NetCore-3.1-dll, witch increments the Build part
of the <FileVersion> property in the Visual Studio Project File automatically after every build. 
It can be used in Visual Studio 2019 projects on Sdk-style project files.

Detailed informations and updates can be found:

https://github.com/FolkerKinzel/IncVersion


Don't move it, don't delete it and don't rename it!